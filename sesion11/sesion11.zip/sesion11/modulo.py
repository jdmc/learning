def borrar_elemento(pos: int, lista: list):
    del lista[pos]
