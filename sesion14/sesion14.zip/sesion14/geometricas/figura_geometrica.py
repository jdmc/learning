class Figura_Geometrica:
    def __init__(self, lado1, lado2):
          self.lado1 = lado1
          self.lado2 = lado2
    
    def calcular_area(self):
         print("Calcular area figura geometrica")

