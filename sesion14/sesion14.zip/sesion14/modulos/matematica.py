import math as m

print(m.sqrt(121))

print(m.ceil(5.05))

print(abs(-5))

print(m.floor(5.95))

print(5**2)

print(m.pow(5,2))

print(m.factorial(7))

