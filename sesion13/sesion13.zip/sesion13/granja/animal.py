class Animal:

    def comer(self):
        return "detectar ubicacion comida"