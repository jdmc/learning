import unittest

def copy_and_add_element(values, element):
    copy = values
    copy.append(element)
    return copy


class TestInequality(unittest.TestCase):
    
    def test_inequality(self):
        
        self.assertNotEqual(1, 2)
        self.assertNotEqual(True, False)
        self.assertNotEqual("Hola", "hola")
        self.assertNotEqual([1,2], [2,1])

    def test_copy_and_add_element(self):
        #triple A o bien A-A-A
        #Arrange: preparacion
        #Act: ejecucion sobre la funcion que quiero probar
        #Assert: verificacion de los resultados (el valor devuelto en la fase Act, y el valor esperado)
        values = [1,2,3]
        element = 4
        expected = [1,2,3,4]
        #Act
        result = copy_and_add_element(values, element)
        #Assert 
        self.assertEqual(result, expected)
        self.assertNotEqual(values, expected, "La lista original no debe ser modificada")
        

if __name__ == "__main__":
    unittest.main()