import unittest

class Address():
    def __init__(self, city, state):
        self.city = city
        self.state = state

class Owner():
    def __init__(self, name, age):
        self.name = name
        self.age = age

class Restaurant():
    def __init__(self, address, owner) -> None:
        self.address = address
        self.owner = owner

    @property
    def owner_age(self):
        return self.owner.age
    
    def summary(self):
        return f"Este restaurante pertenece a {self.owner.name} y esta ubicado en {self.address.city}"

class TestRestaurant(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        print("setUpClass")
    @classmethod
    def tearDownClass(cls) -> None:
        print("tearDownClass")

    def setUp(self) -> None:
        self.address = Address("Santiago", "RM")
        self.owner = Owner("Juan", 30)
        self.restaurant = Restaurant(self.address, self.owner)
    
    def tearDown(self) -> None:
        print("tearDown")

    def test_owner_age(self):
        self.assertEqual(self.restaurant.owner_age, 30)

    @unittest.skip("No quiero probar este test")
    def test_summary(self):
        #self.assertEqual(self.restaurant.summary(), "Este restaurante pertenece a Juan y esta ubicado en Santiago")
        pass

if __name__ == "__main__":
    unittest.main()