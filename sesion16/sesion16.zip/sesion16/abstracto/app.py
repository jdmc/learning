from dog import Dog
from spider import Spider

if __name__ == "__main__":

    snoopy = Dog("Snoopy")
    print(snoopy.num_legs())

    snoopy.eat()

    arana = Spider()
    print(arana.num_legs())


    