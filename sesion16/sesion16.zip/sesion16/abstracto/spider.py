from animal import Animal

class Spider(Animal):
    """Clase que representa una araña"""
    
    def num_legs(self):
        return 8