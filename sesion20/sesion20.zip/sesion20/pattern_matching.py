""" class Special:
    TODAY = "Paella"

menu_diario = input("¿Qué hay de menú hoy? ")

match menu_diario:
    case Special.TODAY:
        print("¡Hoy hay paella!")
    case 'pizza':	
        print("Hoy hay pizza")
    case 'hamburguesa':
        print("Hoy hay hamburguesa")
    case 'ensalada' | 'sopa':
        print("Hoy hay ensalada o sopa")
    case helado if 'vainilla' in helado:
        print("Hoy hay helado de vainilla")
    case helado if helado in ['chocolate', 'fresa', 'vainilla']:
        print("Hoy hay helado de chocolate, fresa y vanilla")
    case 'parallevar':
        print("Hoy hay para llevar")
    case _:
        print("Esto no esta en el menu de hoy") """



class Pizza:
    def __init__(self, topping, second_toping = None):
        self.topping = topping
        self.second = second_toping

""" pizza = Pizza('jam')

match pizza:
    case Pizza(first='pepperoni', second='cheese'):
        print("¡Hoy hay pizza de pepperoni y queso!")
    case Pizza(first='pepperoni', second='onion'):
        print("¡Hoy hay pizza de pepperoni y cebolla!")
    case Pizza(first='pepperoni'):
        print("¡Hoy hay pizza de pepperoni!")
    case Pizza(first='hawaiana'):
        print("¡Hoy hay pizza hawaiana!")
    case _:
        print("No hay pizza hoy") """


order = ['venti', 'no whip', 'mocha latte', 'for here', 'otro dato']

match order:
    case ('tall', *drink, 'for here'):
        drink = ' '.join(drink)
        print(drink)
    case ['venti', *drink, 'for here', _]:
        drink = ' '.join(drink)
        print(drink)
    case _:
        print("No se encontro la orden")


""" order = {
    'size': 'tall',
    'notes': 'no whip',
    'drink': 'mocha latte',
    'serve': 'for here'
}

match order:
    case {'size': 'tall', 'serve': 'for here', **resto}:
        drink = f"{resto['drink']} {resto['notes']}"
        print(drink)
    case _:
        print("No se encontro la orden") """