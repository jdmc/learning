nombre = "Jaime"

def saludar():
    global nombre
    nombre = 'Juan'
    #print("Hola, " + nombre)

saludar()
#print(nombre)

#nonlocal

def order():
    eggs = 12
    
    def cook():
        nonlocal eggs
        eggs = 0
        print(eggs)

    cook()
    print(eggs)

order()