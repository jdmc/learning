import random

def make_dice_cup(sides=6, dice=1):
    def roll(n: int):
        '''Roll the dice'''
        return tuple(random.randint(1, sides) for _ in range(dice))
    
    return roll

#Create a 6-sided dice
d6 = make_dice_cup(sides=7, dice=2)
dato_tirada = d6(10)
print(dato_tirada)


