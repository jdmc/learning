
cantidad = 10

def procesar(a,b):
    return a + b


if (cantidad := procesar(7,5)) == 12:
    print("OK")

print(cantidad)