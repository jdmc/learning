import json

with open('./nearby.json', 'r') as file:
    data = json.load(file)


for clave, dict_anidado in data.items():
    print(clave)
    for clave2, valor2 in dict_anidado.items():
        print(f"{clave2!r}: {valor2!r}")


#print(f"{5+5=}")