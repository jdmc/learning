friend_emails = {
    "Anne": "anne@example.com",
    "Brent": "brent@example.com",
    "Dan": "dan@example.com",
    "David": "david@example.com",
    "Fox": "fox@example.com",
    "Jane": "jane@example.com",
    "Kevin": "kevin@example.com",
    "Robert": "robert@example.com"
}



#preguntar el nombre del amigo para buscar su correo.
# controlando los posibles errores (main errors)
#proceso de busqueda enmarcado en una funcion
#Tiempo: 8min

def buscar_email(nombre: str) -> str:
    try:
        return friend_emails[nombre]
    except KeyError:
        return "No se encontro el correo del amigo"

if __name__ == "__main__":
    nombre = input("Entre nombre de amigo:")
    email = buscar_email(nombre)
    print(email)