import copy

class Taco:
    
    def __init__(self, ingredientes):
        self.ingredientes = copy.copy(ingredientes)
        self.ingredientes = ingredientes[:]


    def add_sauce(self, sauce):
        self.ingredientes.append(sauce)


ingredientes_principales = ['carne', 'cebolla', 'cilantro', 'salsa']
taco = Taco(ingredientes_principales)

otro_taco = copy.deepcopy(taco)

taco.ingredientes[-1] = 'guacamole'
print(taco.ingredientes)

print(otro_taco.ingredientes)



