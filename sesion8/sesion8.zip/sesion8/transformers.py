transformar_data = lambda lista : list(map(lambda alumno : tuple(alumno.split()) ,lista))


