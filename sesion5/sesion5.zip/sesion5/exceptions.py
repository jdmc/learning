
diccionario  = dict(a=1, b=2)

try:
    #resultado = 14 / 0
    #print(resultado)
    data = diccionario["c"]

except (ZeroDivisionError, TypeError):
    print("El error es de tipo numerico")
except KeyError as kex:
    print(f"Clave inexistente:{kex}")
except Exception as ex:
    print(f"Ha habido un error: {ex}")


def convertir_a_entero(data:str) -> int:
    resultado = None
    try:
        resultado = int(data)
    except ValueError:
        pass
    
    return resultado

resultado_entero = convertir_a_entero("Hola")



diccionario = {
    "111H": "Juan",
    "222H": "Paloma"
}

try:
    #del diccionario
    diccionario["111H"] = "Miguel"
    print(diccionario)
except NameError:
    print("Diccionario no existente")
except Exception:
    print("Error general")
else:
    print("Se ha completado satisfactoriamente la operacion")
finally:
    print("Operacion terminada")





