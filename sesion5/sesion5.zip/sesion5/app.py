#tratamiento de clientes
# DNI, Nombre, Apellido, CP

def crear_cliente(data: dict) -> dict:
    id_cliente = data['dni']
    cliente = {id_cliente: data}
    return cliente

def eliminar_cliente(clave: str, diccio: dict):
    if clave in diccio:
        diccio.pop(clave)
    return diccio
    

def buscar_cliente(dni_cliente: str, d_clientes: dict) -> dict:
    
    """
    if dni_cliente not in d_clientes: return #None
    return d_clientes[dni_cliente]
    """
    return d_clientes.get(dni_cliente) # si no existe, devuelve None



def mostrar_clientes(d_clientes: dict):
    if d_clientes is not None:
        for dni, _ in d_clientes.items():
            #print(cliente['dni'])
            print(dni)

#buscar cliente, eliminar client, etc
clientes = dict()

if __name__ == "__main__":
    
    data_cliente1 = {
        'dni':'111H',
        'nombre': 'Juan',
        'apellido': 'Lopez',
        'cp': '08009'
    }
    data_cliente2 = {
        'dni':'222H',
        'nombre': 'Maria',
        'apellido': 'Lopez',
        'cp': '08009'
    }
    data_cliente3 = {
        'dni':'333H',
        'nombre': 'Belen',
        'apellido': 'Fernandez',
        'cp': '28090'
    }

    clientes.update(crear_cliente(data_cliente1))
    clientes.update(crear_cliente(data_cliente2))
    clientes.update(crear_cliente(data_cliente3))

    mostrar_clientes(clientes)

    clave = '222H'
    clientes = eliminar_cliente(clave, clientes)
    mostrar_clientes(clientes)

    #preguntar al usuario el dni y buscar dicho cliente
    cliente = buscar_cliente(input('DNI a buscar?:'), clientes)
    if cliente: 
        print(list(cliente.items())[1:])
    else:
        print("No existe")


