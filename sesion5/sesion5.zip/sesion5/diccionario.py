
#diccionario -> estructura compuesta de pares clave:valor

diccio1 = dict(a=1,b=2,c=3)
diccio2 = {
    "a": 1,
    "b":2,
    "c":3,
}

#se accede al valor a través de la clave
#print(diccio1["f"] if "f" in diccio1 else "No accesible")

print(diccio2["a"])
#KeyError -> cuando no existe la clave por la que queremos preguntar


diccio1["d"] = 20 #alta

print(diccio1)

#edicion
diccio1["a"] = 10 #update
print(diccio1)

#procesar por lotes
new_data = {
    'h': 90,
    'm': 100
}

diccio1.update(new_data)
print(diccio1)

for clave, valor in diccio1.items():
    print(f"Clave:{clave} Valor:{valor}")


x, y, z = diccio2.items()
print(x, y, z)

valores = list(diccio2.values())
print(valores)
print(type(valores))

claves = list(diccio2.keys())
print(claves)
print(type(claves))

#eliminar items
item_eliminado = diccio2.pop("a")
print(diccio2, item_eliminado)

item_eliminado = diccio2.popitem()
print(diccio2)

diccio2.clear()
print(diccio2)

del diccio2
#print(diccio2)

#obtencion o lectura
valor_item = diccio1.get("a")
print(valor_item)

valor_item = diccio1.get("v", -999)
print(valor_item)


mi_diccionario = {
    'a': 100,
    'b': 200,
    'c': 300
}

papelera = dict() #vacia
par_eliminado = mi_diccionario.popitem() # tupla
papelera.update(dict([par_eliminado]))
print(papelera)



""" papelera.update(dict([diccio1.popitem()]))
nuevo_diccionario = dict([("a",6), ("c", 4)]) #diccio1.items() // ("a",([1,2,3])) -> dupla
papelera.update(nuevo_diccionario)

print(papelera) """









