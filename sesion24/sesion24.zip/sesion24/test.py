"""
doc de moculo
"""


class Meta():
    """
    jfdkhjfkdjfkd
    """

    def m1():
        """
        
        """
        #
        pass