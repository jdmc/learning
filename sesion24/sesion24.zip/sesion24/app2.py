import unittest


class TestTrueFalse(unittest.TestCase):
    def test_opcion1(self):
        self.assertTrue(3 < 5)
        self.assertTrue([1])

if __name__ == "__main__":
    unittest.main()
    
    lista = []
    
    if lista:
        print("La lista tiene elementos")