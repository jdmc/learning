import unittest

def dividir(a, b):
    if b == 0:
        raise ZeroDivisionError("No se puede dividir por cero")
    return a / b


class TestDividir(unittest.TestCase):
    def test_dividir(self):
        self.assertRaises(ZeroDivisionError, dividir, 10, 0)
    
    def test_dividir_v2(self):
        with self.assertRaises(ZeroDivisionError):
            dividir(10, 0)

if __name__ == "__main__":
    unittest.main()