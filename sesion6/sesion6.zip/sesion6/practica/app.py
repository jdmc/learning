from proceso import cargar_asignaturas

if __name__ == "__main__":
    asignaturas = None
    asignaturas = cargar_asignaturas(2)
    print(asignaturas)